Some stuff you should know about this theme:

I've only tested this on an iPhone 4(3,1) running a custom iOS 5.1.1 IPSW, but if im not mistaken, this theme SHOULD work on all retina display iPhones.

All of the assets used belong to ATLUS and SEGA.
Original theme, for the PS3:
http://zeus.dl.playstation.net/cdn/EP4062/NPEP00304_00/EP4062-NPEP00304_00-TPERSONA5X000001_bg_1_30405e6b49193d7d4f79b7d4e7ef6e75dd63b600.pkg

Since the Newsstand icon behaves differently from the rest, you will see a black background behind the icon, which makes it look pretty ugly, so if you want, you can use the tweak called NoNewsIsGoodNews (which you can find in the BigBoss repo) to hide the Newsstand icon.

This only modifies the stock Apple icons included in iOS 5.1.1, and as an added bonus, the Cydia icon is also modified.

If you have any doubts or questions, you can always message me through Reddit, I'll try my best to answer.
u/-Salix